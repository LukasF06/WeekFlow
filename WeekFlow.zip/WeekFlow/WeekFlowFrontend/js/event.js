const content = document.getElementById("content");
const moncontent = document.getElementById("mon");
const tuecontent = document.getElementById("tue");
const wedcontent = document.getElementById("wed");
const thucontent = document.getElementById("thu");
const fricontent = document.getElementById("fri");
const satcontent = document.getElementById("sat");
const suncontent = document.getElementById("sun");

const montext = document.getElementById("mon-text");
const tuetext = document.getElementById("tue-text");
const wedtext = document.getElementById("wed-text");
const thutext = document.getElementById("thu-text");
const fritext = document.getElementById("fri-text");
const sattext = document.getElementById("sat-text");
const suntext = document.getElementById("sun-text");

let mcontenttimer = 0;
let tucontenttimer = 0;
let wcontenttimer = 0;
let thcontenttimer = 0;
let fcontenttimer = 0;
let sacontenttimer = 0;
let sucontenttimer = 0;

GetCurrentDay();

fetch("https://localhost:7012/api/Event", {
    headers: {
        "content-type": "application/json",
        credentials: "same-origin",
      },
})
.then(response => response.json())
.then(data => {
    PrintData(data);
});

function PrintData(data) {
    data.forEach(element => {
        const event = document.createElement("div");
        event.classList.add("popup-event");
        event.style.background = element.color;
        event.id = element.id;

        const eventcontent = document.createElement("div");
        eventcontent.classList.add("content-popup");

        const etitlecontent = document.createElement("div");
        etitlecontent.classList.add("content-popup-r");

        const btncontent = document.createElement("div");
        btncontent.classList.add("content-r");

        const etitle = document.createElement("div");
        etitle.classList.add("event-text");
        etitle.style.color = element.color;
        etitle.style.filter = "invert(100%)";
        etitle.innerHTML = element.name;

        const etime = document.createElement("div");
        etime.classList.add("event-text");
        etime.innerHTML = element.time;
        etime.style.color = element.color;
        etime.style.filter = "invert(100%)";
        etime.style.marginTop = "1rem";

        const deletebtn = document.createElement("i");
        deletebtn.classList.add("fa-solid");
        deletebtn.classList.add("fa-trash-can");
        deletebtn.style.color = element.color;
        deletebtn.style.filter = "invert(100%)";
        deletebtn.id = `${element.id}delete`;

        const editbtn = document.createElement("i");
        editbtn.classList.add("fa-solid");
        editbtn.classList.add("fa-pencil");
        editbtn.style.color = element.color;
        editbtn.style.filter = "invert(100%)";
        editbtn.id = `${element.id}edit`;

        btncontent.appendChild(editbtn);
        btncontent.appendChild(deletebtn);    

        if(element.day == "Montag") {
            const monbtn = document.getElementById("mon-btn");
            monbtn.remove();

            etitlecontent.appendChild(etitle);
            etitlecontent.appendChild(btncontent);
            eventcontent.appendChild(etitlecontent);
            eventcontent.appendChild(etime);
            event.appendChild(eventcontent);
            moncontent.appendChild(event);

            mcontenttimer++;

            if(mcontenttimer < 6) {
                moncontent.appendChild(monbtn);
            }

            document.getElementById(event.id).onclick = function() {
                GetDescription(element.description);
            }

            document.getElementById(`${element.id}delete`).onclick = function(layer) {
                DeleteEvent(layer, element.id);
            }

            document.getElementById(`${element.id}edit`).onclick = function(layer) {
                EditEvent(layer, element.id);
            }
        }

        if(element.day == "Dienstag") {
            const tuebtn = document.getElementById("tue-btn");
            tuebtn.remove();

            etitlecontent.appendChild(etitle);
            etitlecontent.appendChild(btncontent);
            eventcontent.appendChild(etitlecontent);
            eventcontent.appendChild(etime);
            event.appendChild(eventcontent);
            tuecontent.appendChild(event);

            tucontenttimer++;

            if(tucontenttimer < 6) {
                tuecontent.appendChild(tuebtn);
            }

            document.getElementById(event.id).onclick = function() {
                GetDescription(element.description);
            }

            document.getElementById(`${element.id}delete`).onclick = function(layer) {
                DeleteEvent(layer, element.id);
            }

            document.getElementById(`${element.id}edit`).onclick = function(layer) {
                EditEvent(layer, element.id);
            }
        }

        if(element.day == "Mittwoch") {
            const wedbtn = document.getElementById("wed-btn");
            wedbtn.remove();

            etitlecontent.appendChild(etitle);
            etitlecontent.appendChild(btncontent);
            eventcontent.appendChild(etitlecontent);
            eventcontent.appendChild(etime);
            event.appendChild(eventcontent);
            wedcontent.appendChild(event);

            wcontenttimer++;

            if(wcontenttimer < 6) {
                wedcontent.appendChild(wedbtn);
            }

            document.getElementById(event.id).onclick = function() {
                GetDescription(element.description);
            }

            document.getElementById(`${element.id}delete`).onclick = function(layer) {
                DeleteEvent(layer, element.id);
            }

            document.getElementById(`${element.id}edit`).onclick = function(layer) {
                EditEvent(layer, element.id);
            }
        }

        if(element.day == "Donnerstag") {
            const thubtn = document.getElementById("thu-btn");
            thubtn.remove();

            etitlecontent.appendChild(etitle);
            etitlecontent.appendChild(btncontent);
            eventcontent.appendChild(etitlecontent);
            eventcontent.appendChild(etime);
            event.appendChild(eventcontent);
            thucontent.appendChild(event);

            thcontenttimer++;

            if(thcontenttimer < 6) {
                thucontent.appendChild(thubtn);
            }

            document.getElementById(event.id).onclick = function() {
                GetDescription(element.description);
            }

            document.getElementById(`${element.id}delete`).onclick = function(layer) {
                DeleteEvent(layer, element.id);
            }

            document.getElementById(`${element.id}edit`).onclick = function(layer) {
                EditEvent(layer, element.id);
            }
        }

        if(element.day == "Freitag") {
            const fribtn = document.getElementById("fri-btn");
            fribtn.remove();

            etitlecontent.appendChild(etitle);
            etitlecontent.appendChild(btncontent);
            eventcontent.appendChild(etitlecontent);
            eventcontent.appendChild(etime);
            event.appendChild(eventcontent);
            fricontent.appendChild(event);

            fcontenttimer++;

            if(fcontenttimer < 6) {
                fricontent.appendChild(fribtn);
            }

            document.getElementById(event.id).onclick = function() {
                GetDescription(element.description);
            }

            document.getElementById(`${element.id}delete`).onclick = function(layer) {
                DeleteEvent(layer, element.id);
            }

            document.getElementById(`${element.id}edit`).onclick = function(layer) {
                EditEvent(layer, element.id);
            }
        }

        if(element.day == "Samstag") {
            const satbtn = document.getElementById("sat-btn");
            satbtn.remove();

            etitlecontent.appendChild(etitle);
            etitlecontent.appendChild(btncontent);
            eventcontent.appendChild(etitlecontent);
            eventcontent.appendChild(etime);
            event.appendChild(eventcontent);
            satcontent.appendChild(event);

            sacontenttimer++;

            if(sacontenttimer < 6) {
                satcontent.appendChild(satbtn);
            }

            document.getElementById(event.id).onclick = function() {
                GetDescription(element.description);
            }

            document.getElementById(`${element.id}delete`).onclick = function(layer) {
                DeleteEvent(layer, element.id);
            }

            document.getElementById(`${element.id}edit`).onclick = function(layer) {
                EditEvent(layer, element.id);
            }
        }

        if(element.day == "Sonntag") {
            const sunbtn = document.getElementById("sun-btn");
            sunbtn.remove();

            etitlecontent.appendChild(etitle);
            etitlecontent.appendChild(btncontent);
            eventcontent.appendChild(etitlecontent);
            eventcontent.appendChild(etime);
            event.appendChild(eventcontent);
            suncontent.appendChild(event);

            sucontenttimer++;

            if(sucontenttimer < 6) {
                suncontent.appendChild(sunbtn);
            }

            document.getElementById(event.id).onclick = function() {
                GetDescription(element.description);
            }

            document.getElementById(`${element.id}delete`).onclick = function(layer) {
                DeleteEvent(layer, element.id);
            }

            document.getElementById(`${element.id}edit`).onclick = function(layer) {
                EditEvent(layer, element.id);
            }
        }
        })
}

document.getElementById("mon-btn").onclick = function() {
    let name = "Montag"; 
    AddDayEvent(name);
}

document.getElementById("tue-btn").onclick = function() {
    let name = "Dienstag"; 
    AddDayEvent(name);
}

document.getElementById("wed-btn").onclick = function() {
    let name = "Mittwoch"; 
    AddDayEvent(name);
}

document.getElementById("thu-btn").onclick = function() {
    let name = "Donnerstag"; 
    AddDayEvent(name);
}

document.getElementById("fri-btn").onclick = function() {
    let name = "Freitag"; 
    AddDayEvent(name);
}

document.getElementById("sat-btn").onclick = function() {
    let name = "Samstag"; 
    AddDayEvent(name);
}

document.getElementById("sun-btn").onclick = function() {
    let name = "Sonntag"; 
    AddDayEvent(name);
}

function GetCurrentDay() {
    const currentDate = new Date();
    const currentDay = currentDate.getDay();
    
    if(currentDay == 1) {
        montext.style.color = "white";
    }
    if(currentDay == 2) {
        tuetext.style.color = "white";
    }
    if(currentDay == 3) {
        wedtext.style.color = "white";
    }
    if(currentDay == 4) {
        thutext.style.color = "white";
    }
    if(currentDay == 5) {
        fritext.style.color = "white";
    }
    if(currentDay == 6) {
        sattext.style.color = "white";
    }
    if(currentDay == 0) {
        suntext.style.color = "white";
    }
}

function AddDayEvent(day) {
    
    const popupbackground = document.createElement("div");
    popupbackground.classList.add("popup-background");
    popupbackground.id = "popupbackground";
    
    const popup = document.createElement("div");
    popup.classList.add("popup");

    const exitbtn = document.createElement("i");
    exitbtn.classList.add("fa-solid");
    exitbtn.classList.add("fa-xmark");
    exitbtn.id = "exitbtn";

    const popupcontent = document.createElement("div");
    popupcontent.classList.add("content-popup");

    const namecontent = document.createElement("div");
    namecontent.classList.add("content-r");

    const namecontent2 = document.createElement("div");
    namecontent2.classList.add("content-r");

    const timecontent = document.createElement("div");
    timecontent.classList.add("content-r");

    const timecontent2 = document.createElement("div");
    timecontent2.classList.add("content-r");

    const popuptextname = document.createElement("div");
    popuptextname.classList.add("popup-text");
    popuptextname.innerHTML = "Event Name:";

    const popuptextcolor = document.createElement("div");
    popuptextcolor.classList.add("popup-text");
    popuptextcolor.innerHTML = "Event Color:";
    popuptextcolor.style.marginLeft = "23rem";

    const popuptexttime = document.createElement("div");
    popuptexttime.classList.add("popup-text");
    popuptexttime.innerHTML = "Start:";
    popuptexttime.style.marginTop = "1.5rem";
    
    const popuptexttime2 = document.createElement("div");
    popuptexttime2.classList.add("popup-text");
    popuptexttime2.innerHTML = "End:";
    popuptexttime2.style.marginTop = "1.5rem";
    popuptexttime2.style.marginLeft = "13rem";

    const popuptextdesc = document.createElement("div");
    popuptextdesc.classList.add("popup-text");
    popuptextdesc.innerHTML = "Description:";
    popuptextdesc.style.marginTop = "1.5rem";

    const nameinput = document.createElement("input");
    nameinput.classList.add("popup-input");
    nameinput.maxLength = 18;
    nameinput.id = "nameinput";

    const colorinput = document.createElement("input");
    colorinput.classList.add("popup-input");
    colorinput.style.width = "5rem";
    colorinput.style.height = "3rem";
    colorinput.style.marginLeft = "4rem";
    colorinput.style.borderBottom = "0";
    colorinput.id = "colorinput";
    colorinput.setAttribute("type", "color");
    colorinput.style.cursor = "pointer";

    const timeinput = document.createElement("input");
    timeinput.classList.add("popup-input");
    timeinput.id = "startinput";
    timeinput.style.width = "13rem";
    timeinput.style.cursor = "pointer";
    timeinput.setAttribute("type", "time");

    const timeinput2 = document.createElement("input");
    timeinput2.classList.add("popup-input");
    timeinput2.id = "endinput";
    timeinput2.style.width = "13rem";
    timeinput2.style.marginLeft = "6rem";
    timeinput2.style.cursor = "pointer";
    timeinput2.setAttribute("type", "time");

    const descinput = document.createElement("textarea");
    descinput.classList.add("popup-input-desc");
    descinput.id = "descinput";
    descinput.maxLength = 300;

    const submitbtn = document.createElement("i");
    submitbtn.classList.add("fa-solid");
    submitbtn.classList.add("fa-check");
    submitbtn.id = "submitbtn";

    document.querySelector("body").style.overflowY = "hidden";

    namecontent.appendChild(popuptextname);
    namecontent.appendChild(popuptextcolor);
    popupcontent.appendChild(namecontent);
    namecontent2.appendChild(nameinput);
    namecontent2.appendChild(colorinput);
    popupcontent.appendChild(namecontent2);

    timecontent.appendChild(popuptexttime)
    timecontent.appendChild(popuptexttime2);
    popupcontent.appendChild(timecontent);
    timecontent2.appendChild(timeinput);
    timecontent2.appendChild(timeinput2);
    popupcontent.appendChild(timecontent2);

    popupcontent.appendChild(popuptextdesc);
    popupcontent.appendChild(descinput);

    popup.appendChild(exitbtn);
    popup.appendChild(popupcontent);
    popup.appendChild(submitbtn);

    popupbackground.appendChild(popup);
    content.appendChild(popupbackground);

    document.getElementById("exitbtn").onclick = function() {
        document.getElementById("popupbackground").remove();
        document.querySelector("body").style.overflowY = "scroll";
    }

    document.getElementById("submitbtn").onclick = function() {

        let name = document.getElementById("nameinput").value;
        let start = document.getElementById("startinput").value;
        let end = document.getElementById("endinput").value;
        let color = document.getElementById("colorinput").value;
        let desc = document.getElementById("descinput").value;

        let time = `${start} - ${end}`;

        fetch("https://localhost:7012/api/Event", {
            method: "POST",
            headers: {
                "content-type": "application/json",
                credentials: "same-origin",
            },
            body: JSON.stringify({
                Name: name,
                Description: desc,
                Day: day,
                Time: time,
                Color: color
            })
        }).then(() => location.reload());

        document.getElementById("popupbackground").remove();
        document.querySelector("body").style.overflowY = "scroll";
    }
    
}

function GetDescription(desc) {

    document.querySelector("body").style.overflowY = "hidden";

    const popupbackground = document.createElement("div");
    popupbackground.classList.add("popup-background");
    popupbackground.id = "popupbackground";

    const popup = document.createElement("div");
    popup.classList.add("desc-popup");

    const exitbtn = document.createElement("i");
    exitbtn.classList.add("fa-solid");
    exitbtn.classList.add("fa-xmark");
    exitbtn.style.marginLeft = "37.5rem";
    exitbtn.id = "exitbtn";

    const desctext = document.createElement("div");
    desctext.classList.add("desc-text");
    desctext.innerHTML = desc;

    popup.appendChild(exitbtn);
    popup.appendChild(desctext)
    popupbackground.appendChild(popup);
    content.appendChild(popupbackground);

    document.getElementById("exitbtn").onclick = function() {
        document.getElementById("popupbackground").remove();
        document.querySelector("body").style.overflowY = "scroll";
    }
}

function DeleteEvent(layer, eventId) {
    layer.stopPropagation();

    fetch("https://localhost:7012/api/Event/" + eventId , {
        method: "DELETE",
        headers: {
            "content-type": "application/json",
            credentials: "same-origin",
        },
    }).then(() => location.reload());
}

function EditEvent(layer, eventId) {
    layer.stopPropagation();

    fetch("https://localhost:7012/api/Event/" + eventId , {
        headers: {
            "content-type": "application/json",
            credentials: "same-origin",
        },
    })
    .then(response => response.json())
    .then(data => {
        const popupbackground = document.createElement("div");
        popupbackground.classList.add("popup-background");
        popupbackground.id = "popupbackground";
        
        const popup = document.createElement("div");
        popup.classList.add("popup");

        const exitbtn = document.createElement("i");
        exitbtn.classList.add("fa-solid");
        exitbtn.classList.add("fa-xmark");
        exitbtn.id = "exitbtn";

        const popupcontent = document.createElement("div");
        popupcontent.classList.add("content-popup");

        const namecontent = document.createElement("div");
        namecontent.classList.add("content-r");

        const namecontent2 = document.createElement("div");
        namecontent2.classList.add("content-r");

        const timecontent = document.createElement("div");
        timecontent.classList.add("content-r");

        const timecontent2 = document.createElement("div");
        timecontent2.classList.add("content-r");

        const popuptextname = document.createElement("div");
        popuptextname.classList.add("popup-text");
        popuptextname.innerHTML = "Event Name:";

        const popuptextcolor = document.createElement("div");
        popuptextcolor.classList.add("popup-text");
        popuptextcolor.innerHTML = "Event Color:";
        popuptextcolor.style.marginLeft = "23rem";

        const popuptexttime = document.createElement("div");
        popuptexttime.classList.add("popup-text");
        popuptexttime.innerHTML = "Start:";
        popuptexttime.style.marginTop = "1.5rem";
        
        const popuptexttime2 = document.createElement("div");
        popuptexttime2.classList.add("popup-text");
        popuptexttime2.innerHTML = "End:";
        popuptexttime2.style.marginTop = "1.5rem";
        popuptexttime2.style.marginLeft = "13rem";

        const popuptextdesc = document.createElement("div");
        popuptextdesc.classList.add("popup-text");
        popuptextdesc.innerHTML = "Description:";
        popuptextdesc.style.marginTop = "1.5rem";

        const nameinput = document.createElement("input");
        nameinput.classList.add("popup-input");
        nameinput.maxLength = 18;
        nameinput.id = "nameinput";
        nameinput.value = data.name;

        const colorinput = document.createElement("input");
        colorinput.classList.add("popup-input");
        colorinput.style.width = "5rem";
        colorinput.style.height = "3rem";
        colorinput.style.marginLeft = "4rem";
        colorinput.style.borderBottom = "0";
        colorinput.id = "colorinput";
        colorinput.setAttribute("type", "color");
        colorinput.style.cursor = "pointer";
        colorinput.value = data.color;

        let timeSplitted = data.time.split(" ");

        const timeinput = document.createElement("input");
        timeinput.classList.add("popup-input");
        timeinput.id = "startinput";
        timeinput.style.width = "13rem";
        timeinput.style.cursor = "pointer";
        timeinput.setAttribute("type", "time");
        timeinput.value = timeSplitted[0];

        const timeinput2 = document.createElement("input");
        timeinput2.classList.add("popup-input");
        timeinput2.id = "endinput";
        timeinput2.style.width = "13rem";
        timeinput2.style.marginLeft = "6rem";
        timeinput2.style.cursor = "pointer";
        timeinput2.setAttribute("type", "time");
        timeinput2.value = timeSplitted[2];

        const descinput = document.createElement("textarea");
        descinput.classList.add("popup-input-desc");
        descinput.id = "descinput";
        descinput.maxLength = 300;
        descinput.value = data.description;

        const submitbtn = document.createElement("i");
        submitbtn.classList.add("fa-solid");
        submitbtn.classList.add("fa-check");
        submitbtn.id = "submitbtn";

        document.querySelector("body").style.overflowY = "hidden";

        namecontent.appendChild(popuptextname);
        namecontent.appendChild(popuptextcolor);
        popupcontent.appendChild(namecontent);
        namecontent2.appendChild(nameinput);
        namecontent2.appendChild(colorinput);
        popupcontent.appendChild(namecontent2);

        timecontent.appendChild(popuptexttime)
        timecontent.appendChild(popuptexttime2);
        popupcontent.appendChild(timecontent);
        timecontent2.appendChild(timeinput);
        timecontent2.appendChild(timeinput2);
        popupcontent.appendChild(timecontent2);

        popupcontent.appendChild(popuptextdesc);
        popupcontent.appendChild(descinput);

        popup.appendChild(exitbtn);
        popup.appendChild(popupcontent);
        popup.appendChild(submitbtn);

        popupbackground.appendChild(popup);
        content.appendChild(popupbackground);

        document.getElementById("exitbtn").onclick = function() {
            document.getElementById("popupbackground").remove();
            document.querySelector("body").style.overflowY = "scroll";
        }

        document.getElementById("submitbtn").onclick = function() {

            let name = document.getElementById("nameinput").value;
            let start = document.getElementById("startinput").value;
            let end = document.getElementById("endinput").value;
            let color = document.getElementById("colorinput").value;
            let desc = document.getElementById("descinput").value;

            let time = `${start} - ${end}`;

            fetch("https://localhost:7012/api/Event/" + eventId , {
                method: "PUT",
                headers: {
                    "content-type": "application/json",
                    credentials: "same-origin",
                },
                body: JSON.stringify({
                    Id: data.id,
                    Name: name,
                    Description: desc,
                    Time: time,
                    Color: color
                })
            }).then(() => location.reload());

            document.getElementById("popupbackground").remove();
            document.querySelector("body").style.overflowY = "scroll";
        }
    });   
}

function Exit() {
    window.location.href = "index.html";
}
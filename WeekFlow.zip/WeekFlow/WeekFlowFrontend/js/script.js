document.getElementById("weeksurface").onclick = function() {
    window.location.href = "week.html";
}

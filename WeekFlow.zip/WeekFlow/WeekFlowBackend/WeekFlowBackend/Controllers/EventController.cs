﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WeekFlowBackend.Model;

namespace WeekFlowBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventController : ControllerBase
    {
        private readonly EventDb _db;

        public EventController(EventDb context)
        {
            _db = context;
        }

        [HttpGet] //read all
        public async Task<ActionResult<IEnumerable<Event>>> GetEvent()
        {
            if(_db.Events == null)
            {
                return NotFound();
            }

            return await _db.Events.Select(x => EventDbList(x)).ToListAsync();
        }

        [HttpGet("{id}")] //read by Id
        public async Task<ActionResult<Event>> GetEvent(int id)
        {
            if(_db.Events == null)
            {
                return NotFound();
            }

            var searchedEvent = await _db.Events.FindAsync(id);

            if(searchedEvent == null)
            {
                return NotFound();
            }

            return EventDbList(searchedEvent);
        }

        [HttpPost] //create
        public async Task<ActionResult<EventDTO>> PostEvent(EventDTO eventDTO)
        {
            var newEvent = new Event
            {
                Name = eventDTO.Name,
                Description = eventDTO.Description,
                Day = eventDTO.Day,
                Time = eventDTO.Time,
                Color = eventDTO.Color,
            };

            _db.Events.Add(newEvent);
            await _db.SaveChangesAsync();

            return CreatedAtAction("GetEvent", new { id = newEvent.Id }, eventDTO);
        }

        [HttpDelete("{id}")] //delete by Id
        public async Task<IActionResult> DeleteCoffee(int id)
        {
            if(_db.Events == null)
            {
                return NotFound();
            }
            var searchedEvent = await _db.Events.FirstOrDefaultAsync(x => x.Id == id);
            if(searchedEvent == null)
            {
                return NotFound();
            }

            _db.Events.Remove(searchedEvent);
            await _db.SaveChangesAsync();

            return NoContent();
        }

        [HttpPut("{id}")] //update by id
        public async Task<IActionResult> PutCoffee(int id, Event newEvent)
        {
            if (id != newEvent.Id)
            {
                return BadRequest();
            }
            var eventToUpdate = await _db.Events.FirstOrDefaultAsync(x => x.Id == newEvent.Id);
            if (eventToUpdate == null)
            {
                return NotFound();
            }

            eventToUpdate.Name = newEvent.Name;
            eventToUpdate.Description = newEvent.Description;
            eventToUpdate.Day = eventToUpdate.Day;
            eventToUpdate.Time = newEvent.Time;
            eventToUpdate.Color = newEvent.Color;

            _db.Entry(eventToUpdate).State = EntityState.Modified;

            try
            {
                await _db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EventExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        private static Event EventDbList(Event searchedevent)
        {
            return new Event
            {
                Id = searchedevent.Id,
                Name = searchedevent.Name,
                Description = searchedevent.Description,
                Day = searchedevent.Day,
                Time = searchedevent.Time,
                Color = searchedevent.Color,
            };
        }

        private bool EventExists(int id)
        {
            return (_db.Events?.Any(x => x.Id == id)).GetValueOrDefault();
        }
    }
}

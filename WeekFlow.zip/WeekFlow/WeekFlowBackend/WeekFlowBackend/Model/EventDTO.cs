﻿namespace WeekFlowBackend.Model
{
    public class EventDTO
    {
        public string Name { get; set; } = string.Empty;

        public string Description { get; set; } = string.Empty;

        public string Day { get; set; } = string.Empty;

        public string Time { get; set; } = string.Empty;

        public string Color { get; set; } = string.Empty;
    }
}

﻿using System.ComponentModel.DataAnnotations;

namespace WeekFlowBackend.Model
{
    public class Event
    {
        [Key]
        public int Id { get; set; }

        public string Name { get; set; } = string.Empty;

        public string Description { get; set; } = string.Empty;

        public string Day { get; set; } = string.Empty;

        public string Time { get; set; } = string.Empty;

        public string Color { get; set; } = string.Empty;
    }
}
